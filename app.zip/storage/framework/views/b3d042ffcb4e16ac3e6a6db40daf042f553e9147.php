<div class=" ">
  <nav class="w-full h-30 px-2 py-1 bg-gray-600 text-white flex md:flex-row flex-wrap items-center justify-between">
    <div class="flex items-center justify-between md:justify-none md:w-max w-full">
      <div class="flex md:block justify-between items-center mb-2 md:mb-0">
        <a href="<?php echo e(route('user/index')); ?>" class=" text-none border-r-2 border-black text-lg font-semibold p-3 flex flex-col"><span class="text-center">حل الملف </span><span>File Solution</span></a>
        
      </div>
      <a class="text-lg hover:text-blue-200 font-semibold" href="<?php echo e(route('user/embassy_list')); ?>" > <i class="fa fa-list-alt text-xl pl-6 mr-2" aria-hidden="true"></i>Create Embassy List</a>
    </div>

    <div class="right items-center md:w-min w-full gap-2 flex justify-center space-x-2">
        

         <button  data-bs-toggle="modal" class="text-2xl" data-bs-target="#user" data-toggle="tooltip" data-placement="bottom" title="Edit Profile">
            <span><i class="fa-regular fa-user " ></i></span>
         </button>

      

         <button data-toggle="tooltip" class="text-2xl w-full pt-2" data-placement="bottom" title="Notification">
           <span class="mt-2"><i class="bi bi-bell "></i></span>
         </button>
         <button class="text-xl flex justify-center items-center p-3 shadow-xl bg-gray-100 w-[40px] h-[40px] rounded-full " data-toggle="tooltip" data-placement="bottom" title="Logout" >
             <a href="<?php echo e(route('user/logout')); ?>" class="flex gap-2 font-bold text-xl"><i class="bi text-red-700 font-bold bi-box-arrow-left"></i></a>
             
         </button>
       
    
    </div>
</nav>
  
</div>

  
<?php /**PATH C:\xampp\htdocs\embassy_laravel-main\resources\views/layout/navbar.blade.php ENDPATH**/ ?>