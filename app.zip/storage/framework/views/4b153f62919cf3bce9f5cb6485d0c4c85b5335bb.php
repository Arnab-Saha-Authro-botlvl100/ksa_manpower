<div class=" ">
  <nav class="w-full h-30 px-2 py-1 bg-gray-600 text-white flex items-center justify-between">
    <div class="flex items-center md:w-max w-full">
      <div class="flex md:block justify-between items-center mb-2 md:mb-0">
        <a href="<?php echo e(route('user/index')); ?>" class=" text-none border-r-2 border-black text-lg font-semibold p-3 flex flex-col"><span class="text-center">حل الملف </span><span>File Solution</span></a>
        
      </div>
      <a class="text-lg hover:text-blue-200 font-semibold flex" href="<?php echo e(route('user/embassy_list')); ?>" > <i class="fa fa-list-alt text-xl pl-6 mr-2" aria-hidden="true"></i><p class="md:block hidden"> Create Embassy List</p></a>
    </div>

    <div class=" items-center gap-2 flex justify-center space-x-2">
        

         <button  data-bs-toggle="modal" class="text-2xl w-full p-2 rounded-full border-1 border-white w-[40px] h-[40px] flex justify-center items-center" data-bs-target="#user" data-toggle="tooltip" data-placement="bottom" title="Edit Profile">
            <span><i class="fa-regular fa-user " ></i></span>
         </button>

      

         <button data-toggle="tooltip" class="text-2xl w-full p-2 rounded-full border-1 border-white w-[40px] h-[40px] flex justify-center items-center" data-placement="bottom" title="Notification">
           <span class=""><i class="bi bi-bell "></i></span>
         </button>
         <button class="text-xl flex  justify-center items-center p-3 shadow-xl border-1 border-white w-[40px] h-[40px] rounded-full font-bold" data-toggle="tooltip" data-placement="bottom" title="Logout" >
             <a href="<?php echo e(route('user/logout')); ?>" class="flex gap-2 font-bold text-xl"><i class="bi text-white font-bold bi-box-arrow-left"></i></a>
             
         </button>
       
    
    </div>
</nav>
  
</div>

  
<?php /**PATH /home/ksavyhor/visa_form/resources/views/layout/navbar.blade.php ENDPATH**/ ?>